﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _301176481_JayPandyaLab2
{
  
    public delegate void SubscribeEmailDelegate(SendViaEmail email);
    public delegate void SubscribeSMSDelegate(SendViaMobile sms);
    public delegate void UnsubscribeEmailDelegate(SendViaEmail unsubEmail);
    public delegate void UnsubscribeSMSDelegate(SendViaMobile unsubSMS);
    public partial class PublishNotificationForm : Form
    {
        
        List<SendViaEmail> emlCollections = new List<SendViaEmail>();
        List<SendViaMobile> smscnsl = new List<SendViaMobile>();

       
        public SubscribeEmailDelegate subsDelegate;
        public SubscribeSMSDelegate subsemldelegate;
        public UnsubscribeEmailDelegate unsubemldelegate;
        public UnsubscribeSMSDelegate unsubememaildlde;

        public ManageSubscription manageSubscription;
        public PublishNotificationForm()
        {
            InitializeComponent();
            subsDelegate = SubscribeEmail;
            subsemldelegate = SubscribeSMS;
            unsubemldelegate = UnsubscribeEmail;
            unsubememaildlde = UnsubscribeSMS;
        }
        
        void SubscribeEmail(SendViaEmail objEmail)
        {
           
            if (emlCollections.Contains(objEmail))
            {
                MessageBox.Show("Subscriber Already Subscribed");
            }
            else
            {
                emlCollections.Add(objEmail);
                MessageBox.Show("Subscribed :) ");
            }

        }
        void SubscribeSMS(SendViaMobile objSMS)
        {
            if (smscnsl.Contains(objSMS))
            {
                MessageBox.Show("Subscriber Already Subscribed");
            }
            else
            {
                smscnsl.Add(objSMS);
                MessageBox.Show("Subscribed :) ");
            }
        }

        void UnsubscribeEmail(SendViaEmail unsubeml)
        {
            if (!emlCollections.Contains(unsubeml))
            {
                MessageBox.Show("You Are Not Subscribed");
            }
            else
            {
                emlCollections.Remove(unsubeml);
                MessageBox.Show("Unsubscribed :( ");
            }

        }
        void UnsubscribeSMS(SendViaMobile unsubSMS)
        {
            if (!smscnsl.Contains(unsubSMS))
            {
                MessageBox.Show("You Are Not Subscribed");
            }
            else
            {
                smscnsl.Remove(unsubSMS);
                MessageBox.Show("Unsubscried :( ");
            }

        }

      
      

     

        private void PublishNotificationForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonPublish_Click_1(object sender, EventArgs e)
        {
            string text = textBoxNotifcation.Text;
            foreach (SendViaEmail email in emlCollections)
            {
                email.lbMessage += text + "\n";
            }
            foreach (SendViaMobile sms in smscnsl)
            {
                sms.lbMessage += text + "\n";
            }
            string smsMessages = "";
            foreach (SendViaMobile sms in smscnsl)
            {
                smsMessages += sms.ToString() + "\n";
            }
            string emailMessages = "";
            foreach (SendViaEmail email in emlCollections)
            {
                emailMessages += email.ToString() + "\n";
            }
            string messages = "SMS: \n" + smsMessages + "Email: \n" + emailMessages;
            manageSubscription.dspldelegate(messages);
        }

        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            Hide();
        }

        private void textBoxNotifcation_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
