﻿namespace _301176481_JayPandyaLab2
{
    partial class PublishNotificationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNotifcation = new System.Windows.Forms.Label();
            this.textBoxNotifcation = new System.Windows.Forms.TextBox();
            this.buttonPublish = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelNotifcation
            // 
            this.labelNotifcation.AutoSize = true;
            this.labelNotifcation.Location = new System.Drawing.Point(119, 111);
            this.labelNotifcation.Name = "labelNotifcation";
            this.labelNotifcation.Size = new System.Drawing.Size(229, 32);
            this.labelNotifcation.TabIndex = 0;
            this.labelNotifcation.Text = "Notification Context";
            // 
            // textBoxNotifcation
            // 
            this.textBoxNotifcation.Location = new System.Drawing.Point(430, 108);
            this.textBoxNotifcation.Name = "textBoxNotifcation";
            this.textBoxNotifcation.Size = new System.Drawing.Size(249, 39);
            this.textBoxNotifcation.TabIndex = 1;
            this.textBoxNotifcation.TextChanged += new System.EventHandler(this.textBoxNotifcation_TextChanged);
            // 
            // buttonPublish
            // 
            this.buttonPublish.Location = new System.Drawing.Point(119, 275);
            this.buttonPublish.Name = "buttonPublish";
            this.buttonPublish.Size = new System.Drawing.Size(150, 46);
            this.buttonPublish.TabIndex = 2;
            this.buttonPublish.Text = "Publish";
            this.buttonPublish.UseVisualStyleBackColor = true;
            this.buttonPublish.Click += new System.EventHandler(this.buttonPublish_Click_1);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(479, 275);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(150, 46);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // PublishNotificationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonPublish);
            this.Controls.Add(this.textBoxNotifcation);
            this.Controls.Add(this.labelNotifcation);
            this.Name = "PublishNotificationForm";
            this.Text = "PublishNotificationForm";
            this.Load += new System.EventHandler(this.PublishNotificationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelNotifcation;
        private TextBox textBoxNotifcation;
        private Button buttonPublish;
        private Button buttonExit;
    }
}