﻿namespace _301176481_JayPandyaLab2
{
    partial class NotificationManagerForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonManageSubscription = new System.Windows.Forms.Button();
            this.ButtonPubNotifcation = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonManageSubscription
            // 
            this.buttonManageSubscription.Location = new System.Drawing.Point(67, 194);
            this.buttonManageSubscription.Name = "buttonManageSubscription";
            this.buttonManageSubscription.Size = new System.Drawing.Size(165, 68);
            this.buttonManageSubscription.TabIndex = 0;
            this.buttonManageSubscription.Text = "Manage";
            this.buttonManageSubscription.UseVisualStyleBackColor = true;
            this.buttonManageSubscription.Click += new System.EventHandler(this.buttonManageSubscription_Click);
            // 
            // ButtonPubNotifcation
            // 
            this.ButtonPubNotifcation.Location = new System.Drawing.Point(270, 194);
            this.ButtonPubNotifcation.Name = "ButtonPubNotifcation";
            this.ButtonPubNotifcation.Size = new System.Drawing.Size(272, 68);
            this.ButtonPubNotifcation.TabIndex = 1;
            this.ButtonPubNotifcation.Text = "Publish Notification";
            this.ButtonPubNotifcation.UseVisualStyleBackColor = true;
            this.ButtonPubNotifcation.Click += new System.EventHandler(this.ButtonPubNotifcation_Click_1);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(593, 194);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(165, 68);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click_1);
            // 
            // NotificationManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.ButtonPubNotifcation);
            this.Controls.Add(this.buttonManageSubscription);
            this.Name = "NotificationManagerForm";
            this.Text = "Notification Manager Form";
            this.Load += new System.EventHandler(this.NotificationManagerForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button buttonManageSubscription;
        private Button ButtonPubNotifcation;
        private Button buttonExit;
    }
}