﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _301176481_JayPandyaLab2
{

    public delegate void DisplayDelegate(string mltxt);
    public partial class ManageSubscription : Form
    {
        public DisplayDelegate dspldelegate;
        private PublishNotificationForm pubfrm;
        public ManageSubscription(PublishNotificationForm publishForm)
        {
            InitializeComponent();
            this.pubfrm = publishForm;
            dspldelegate = Display;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
      
        public void Display(string messages)
        {
            MessageBox.Show(messages);
        }
       
        private void ManageSubscription_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void buttonSubscribe_Click_1(object sender, EventArgs e)
        {
         
            if (checkSentEmail.Checked)
            {
                string email = textBoxEmail.Text;

                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(email);
                if (match.Success)
                {
                    SendViaEmail sendViaEmail = new SendViaEmail(email);
                    pubfrm.subsDelegate(sendViaEmail);
                }

                else
                {
                    MessageBox.Show("Invalid Email Entered");
                }

            }
            if (checkSendSms.Checked)
            {
                string pubsms = textBoxSMS.Text;
                Regex regex = new Regex(@"^[2-9]\d{2}-\d{3}-\d{4}$");
                Match match = regex.Match(pubsms);
                if (match.Success)
                {
                    SendViaMobile sendViaMobile = new SendViaMobile(pubsms);
                    pubfrm.subsemldelegate(sendViaMobile);
                }

                else
                {
                    MessageBox.Show("Invalid Phone Number Entered");
                }

            }
        }

        private void buttonUnsubscribe_Click_1(object sender, EventArgs e)
        {
            
            if (checkSentEmail.Checked)
            {
                string email = textBoxEmail.Text;
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(email);
                if (match.Success)
                {
                    SendViaEmail sendViaEmail = new SendViaEmail(email);
                    pubfrm.unsubemldelegate(sendViaEmail);
                }

                else
                {
                    MessageBox.Show("Invalid Email Entered");
                }

            }
            if (checkSendSms.Checked)
            {
                string sms = textBoxSMS.Text;
                Regex regex = new Regex(@"^[2-9]\d{3}-\d{3}-\d{4}$");
                Match match = regex.Match(sms);
                if (match.Success)
                {
                    SendViaMobile sendViaMobile = new SendViaMobile(sms);
                    pubfrm.unsubememaildlde(sendViaMobile);
                }
                else
                {
                    MessageBox.Show("Invalid Phone Number Entered");
                }

            }

        }

        private void buttonCancel_Click_1(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
