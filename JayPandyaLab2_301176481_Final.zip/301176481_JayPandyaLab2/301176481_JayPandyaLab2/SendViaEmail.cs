﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301176481_JayPandyaLab2
{
    public class SendViaEmail
    {
        public string lbEmail { get; set; }
        public string lbMessage { get; set; }
        public SendViaEmail(string email)
        {
            lbEmail = email;
            lbMessage = "";
        }
        public override string ToString()
        {
            return lbEmail + ":" + lbMessage;
        }


        public override bool Equals(Object lbObj)

        {
            if (lbObj is string)
            {
                return lbEmail.Equals((string)lbObj);
            }
            else if (lbObj is SendViaEmail)
            {
                return lbEmail.Equals(((SendViaEmail)lbObj).lbEmail);
            }

            return false;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
    }
}
