﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301176481_JayPandyaLab2
{
    public class SendViaMobile
    {
        public string lbSMS { get; set; }
        public string lbMessage { get; set; }

        public SendViaMobile(string sms)
        {
            lbSMS = sms;
            lbMessage = "";
        }
        public override bool Equals(Object lbObj)
        {
            if (lbObj is string)
            {
                return lbSMS.Equals((string)lbObj);
            }
            else if (lbObj is SendViaMobile)
            {
                return lbSMS.Equals(((SendViaMobile)lbObj).lbSMS);
            }

            return false;
        }
        public override string ToString()
        {
            return lbSMS + ":" + lbMessage;
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
    }
}
