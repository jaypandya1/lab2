﻿namespace _301176481_JayPandyaLab2
{
    partial class ManageSubscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkSentEmail = new System.Windows.Forms.CheckBox();
            this.checkSendSms = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxSMS = new System.Windows.Forms.TextBox();
            this.buttonSubscribe = new System.Windows.Forms.Button();
            this.buttonUnsubscribe = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkSentEmail
            // 
            this.checkSentEmail.AutoSize = true;
            this.checkSentEmail.Location = new System.Drawing.Point(63, 84);
            this.checkSentEmail.Name = "checkSentEmail";
            this.checkSentEmail.Size = new System.Drawing.Size(329, 36);
            this.checkSentEmail.TabIndex = 0;
            this.checkSentEmail.Text = "Notification Send By Email";
            this.checkSentEmail.UseVisualStyleBackColor = true;
            this.checkSentEmail.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkSendSms
            // 
            this.checkSendSms.AutoSize = true;
            this.checkSendSms.Location = new System.Drawing.Point(63, 195);
            this.checkSendSms.Name = "checkSendSms";
            this.checkSendSms.Size = new System.Drawing.Size(340, 36);
            this.checkSendSms.TabIndex = 1;
            this.checkSendSms.Text = "Notification Send By Phone";
            this.checkSendSms.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(602, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 32);
            this.label1.TabIndex = 2;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(500, 82);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(258, 39);
            this.textBoxEmail.TabIndex = 3;
            // 
            // textBoxSMS
            // 
            this.textBoxSMS.Location = new System.Drawing.Point(500, 195);
            this.textBoxSMS.Name = "textBoxSMS";
            this.textBoxSMS.Size = new System.Drawing.Size(258, 39);
            this.textBoxSMS.TabIndex = 4;
            // 
            // buttonSubscribe
            // 
            this.buttonSubscribe.Location = new System.Drawing.Point(94, 332);
            this.buttonSubscribe.Name = "buttonSubscribe";
            this.buttonSubscribe.Size = new System.Drawing.Size(174, 71);
            this.buttonSubscribe.TabIndex = 5;
            this.buttonSubscribe.Text = "Subscribe";
            this.buttonSubscribe.UseVisualStyleBackColor = true;
            this.buttonSubscribe.Click += new System.EventHandler(this.buttonSubscribe_Click_1);
            // 
            // buttonUnsubscribe
            // 
            this.buttonUnsubscribe.Location = new System.Drawing.Point(374, 332);
            this.buttonUnsubscribe.Name = "buttonUnsubscribe";
            this.buttonUnsubscribe.Size = new System.Drawing.Size(174, 71);
            this.buttonUnsubscribe.TabIndex = 6;
            this.buttonUnsubscribe.Text = "UnSubscribe";
            this.buttonUnsubscribe.UseVisualStyleBackColor = true;
            this.buttonUnsubscribe.Click += new System.EventHandler(this.buttonUnsubscribe_Click_1);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(620, 332);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(174, 71);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click_1);
            // 
            // ManageSubscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 475);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonUnsubscribe);
            this.Controls.Add(this.buttonSubscribe);
            this.Controls.Add(this.textBoxSMS);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkSendSms);
            this.Controls.Add(this.checkSentEmail);
            this.Name = "ManageSubscription";
            this.Text = "ManageSubscription";
            this.Load += new System.EventHandler(this.ManageSubscription_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CheckBox checkSentEmail;
        private CheckBox checkSendSms;
        private Label label1;
        private TextBox textBoxEmail;
        private TextBox textBoxSMS;
        private Button buttonSubscribe;
        private Button buttonUnsubscribe;
        private Button buttonCancel;
    }
}