using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _301176481_JayPandyaLab2
{
   
        public partial class NotificationManagerForm : Form
        {
            ManageSubscription mngfrm;
            PublishNotificationForm pbfrm;
            public NotificationManagerForm()
            {
                InitializeComponent();
                pbfrm = new PublishNotificationForm();
                mngfrm = new ManageSubscription(pbfrm);
                pbfrm.manageSubscription = mngfrm;

            }

         

          

       

            private void NotificationManagerForm_Load(object sender, EventArgs e)
            {

            }

        private void buttonManageSubscription_Click(object sender, EventArgs e)
        {
            mngfrm.Show();
            ButtonPubNotifcation.Enabled = true;
        }

        private void buttonExit_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void ButtonPubNotifcation_Click_1(object sender, EventArgs e)
        {
            pbfrm.Show();
        }
    }
    
}